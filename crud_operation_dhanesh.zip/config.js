// config.js
module.exports = {
  mongoURI: 'mongodb+srv://anup8899:Anup%4018899@cluster0.p3jxj.mongodb.net/CRUDDhanesh?retryWrites=true&w=majority'
};
