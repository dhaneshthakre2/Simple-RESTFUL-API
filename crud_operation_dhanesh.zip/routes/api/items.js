// routes/api/items.js
const express = require('express');
const router = express.Router();
const Item = require('../../models/Item');

// @route   GET api/items
// @desc    Get all items
router.get('/', (req, res) => {
  Item.find()
    .then(items => res.json(items))
    .catch(err => res.status(500).json({ error: err.message }));
});

// @route   POST api/items
// @desc    Create an item
router.post('/', (req, res) => {
  const newItem = new Item({
    title: req.body.title,
    description: req.body.description,
    status: req.body.status
  });

  newItem.save()
    .then(item => res.json(item))
    .catch(err => res.status(500).json({ error: err.message }));
});

// @route   PUT api/items/:id
// @desc    Update an item
router.put('/:id', (req, res) => {
  Item.findByIdAndUpdate(req.params.id, req.body)
    .then(() => res.json({ success: true }))
    .catch(err => res.status(500).json({ error: err.message }));
});

// @route   DELETE api/items/:id
// @desc    Delete an item
router.delete('/:id', (req, res) => {
  Item.findByIdAndRemove(req.params.id)
    .then(() => res.json({ success: true }))
    .catch(err => res.status(500).json({ error: err.message }));
});

module.exports = router;
