const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const config = require('./config');


// Import routes
const items = require('./routes/api/items');
const app = express();

// Body parser middleware
app.use(bodyParser.json());

// Use routes
app.use('/api/items', items);

// MongoDB Atlas connection
mongoose
  .connect(config.mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

// Define your MongoDB schema and model here

// Define your CRUD routes here

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server is running on port ${port}`));
